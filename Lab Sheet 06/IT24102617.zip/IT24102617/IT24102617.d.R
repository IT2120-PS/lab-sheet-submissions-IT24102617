setwd("C:\\Users\\user\\Desktop\\IT24102617")
getwd()

#part 1
#(i) Binomial ditribution

#(ii) 
pbinom(46,50,0.85,lower.tail=FALSE)

#part 2

#(i) number of cells received in one hour

#(ii) random variable x has poisson distribution with lambda = 12

#(iii) 
dpois(15,12)
